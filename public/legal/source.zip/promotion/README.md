Folder for videos, screenshots and thumbnails used to promote pixelplanet
