license: free  
website: http://www.moorstation.org/typoasis/designers/gemnew/home.htm