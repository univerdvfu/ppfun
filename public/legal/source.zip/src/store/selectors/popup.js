/*
 * selectors for single window / popup
 */

export const selectWindowType = (state) => state.popup.windowType;

export const selectWindowArgs = (state) => state.popup.args;
