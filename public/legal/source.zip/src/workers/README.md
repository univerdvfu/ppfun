# Worker Threads

Every single .js file here automatically gets its own webpack entry point and
will get build into its own worker/filename file.
